<nav class="menu">
    <button onclick="window.location.href='index.php';"><b>Моя сторінка</b></button>
    <button onclick="window.location.href='others_page.php';"><b>Інші юзери</b></button>
    <button onclick="window.location.href='settings.php';"><b>Налаштування</b></button>
    <button onclick="window.location.href='log_in.php';"><b>Вихід <?php echo "$UID" ?></b></button>
  </nav>

<!--style="background-color:#ff9502ff;"-->
