<?php
    session_start();
    $UID = $_SESSION['id'];
session_start();
$link = mysqli_connect("localhost", "zl0ta", "ins3cwetr4st", "zl0ta_");

  //перевірка під'єднання до БД
if (!$link) {
  echo "Помилка: неможливо встановити з'єднання з MySQL." . PHP_EOL;
  echo "Код помилки errno: " . mysqli_connect_errno() . PHP_EOL;
  echo "Текст помилки error: " . mysqli_connect_error() . PHP_EOL;
  exit;
}

  //відправляємо запит до БД
$link->query("SET NAMES 'utf8'");

/*якщо була натиснута 1-а кнопка*/
if (isset($ok1)) {

  $stmt = mysqli_stmt_init($link);
  if (mysqli_stmt_prepare($stmt, 'UPDATE `u_data` SET `login` = ? WHERE `login`= $_SESSION')) {
    mysqli_stmt_bind_param($stmt, "sss", $login);
    $login = $_POST['login'];
    if (mysqli_stmt_execute($stmt)) {
      echo "Логін успішно змінено!";
    }
    mysqli_stmt_close($stmt);
  }

  /*якщо була натиснута 2-а кнопка*/
  if (isset($ok2)) {
    $stmt = mysqli_stmt_init($link);
    if (mysqli_stmt_prepare($stmt, 'UPDATE `u_data` SET `name` = ? WHERE `login`= $_SESSION')) {
      mysqli_stmt_bind_param($stmt, "sss", $name);
      $name = $_POST['login'];
      if (mysqli_stmt_execute($stmt)) {
        echo "Ім'я успішно змінено!";
      }
      mysqli_stmt_close($stmt);
    };

    /*якщо була натиснута 3-я кнопка*/
    if (isset($ok3)) {
      $stmt = mysqli_stmt_init($link);
      if (mysqli_stmt_prepare($stmt, 'UPDATE `u_data` (`password`) SET `password` = ? WHERE `login`= $_SESSION')) {
        mysqli_stmt_bind_param($stmt, "sss", $password);
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        if (mysqli_stmt_execute($stmt)) {
          echo "Пароль успішно змінено!";
        }
        mysqli_stmt_close($stmt);
      }
    }
  }
};

$link->close();
?>