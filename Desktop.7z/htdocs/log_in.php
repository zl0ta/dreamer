<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8" />
  <title> Вхід </title>
  <meta name="viewport" content="width=device-width, initial_scale=1.0">   <!-- адаптивность к мобильным устройствам -->
  <link rel="stylesheet" href="css/based.css">
	<link rel="stylesheet" href="css/log_reg.css">
	<link rel="stylesheet" href="php/log_in_.php">
</head>
<body>
	<form action="php/log_in_.php" method="post">
		<p class="text"> Логін: </p>
		<input name="login" type="text">

		<p class="text"> Пароль: </p>
		<input type="Password" name="password" id="Password" autocomplete="off">
		<br><br>
		<input type="submit" name="log_in" value="Увійти"  class="button">
	</form>

	<button onclick="window.location.href='reg.php'"> Реєстрація </button>
</body>
</html>
