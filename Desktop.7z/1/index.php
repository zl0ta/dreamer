<?php
  //if (!isset($_SESSION['login'])) header("Location: log_in.php");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title> My profile </title>
  <meta name="viewport" content="width=device-width, initial_scale=1.0">   <!--  адаптивность к мобильным устройствам -->
  <link rel="stylesheet" href="css/based.css">
</head>
<body>
  <?php echo file_get_contents("/var/www/zl0ta/pub/menu.php"); ?>

  <!-- Фото профілю кожного користувача -->
  <?php /*header("Location: img_from_folder.php";*/ ?>

</body>
</html>
