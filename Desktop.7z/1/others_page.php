<!DOCTYPE html>
<head>
  <title>Інші користувачі</title>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial_scale=1.0">   <!--  адаптивность к мобильным устройствам-->
  <link rel="stylesheet" href="css/based.css">
  <link rel="stylesheet" href="php/settings.php">
</head>
<body>

  <?php echo file_get_contents("menu.php"); ?>

  <!--<hr color="#c40024" width="100%" height="5px"></hr>-->
  <div class="table_1">
    <h2>Користувачі</h2>

    <table>
    <tr>
    <th>Ім'я користувача</th>
    <th>Дата реєстрації</th>
    <th>ID юзера</th>
    </tr>
    <?php require 'php/others_.php';?>
</table>





    <p>Test2</p>
  </div>

</body>
</html>
